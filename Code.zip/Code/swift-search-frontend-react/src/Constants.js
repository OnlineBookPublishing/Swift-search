const Constants = {
    elasticSearchAppName:"database_9",
    elasticSearchUrl:"http://178.128.236.69:9200"
    //elasticSearchUrl:"http://192.168.2.86:9200/"
}

export default Constants
